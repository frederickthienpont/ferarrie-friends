<h1 align="center">🚗FiveM Car Pack ( 174 cars)</h1>
<p align="center">
    <img alt="" src="https://img.shields.io/github/stars/Zerofour04/FiveM-BigCarPack.svg?style=for-the-badge">
    <img alt="" src="https://madewithlove.now.sh/de?heart=true&colorB=%23ec2237&template=for-the-badge">
    <img alt="" src="https://img.shields.io/github/followers/Zerofour04.svg?style=for-the-badge&label=Follow&maxAge=2592000">
</p>

## ℹ️Information
- Hey everyone! Two years ago, a friend and I created this car pack and decided to share it with the community.
- We put a lot of effort into providing a diverse selection of cars.
- I'd also like to mention that the content of this pack is mainly sourced from 5MODS, as there hasn't been a comparable package available until now. A big thank you to the original creators for their fantastic work! Feel free to contact me if there are specific contents you'd like to have removed!
- If you enjoy it, please consider giving it a ⭐️ star!
- I made this FiveM Carpack as I made all these cars FiveM Ready and set them to the realistic speed. **Every car drives as fast as in real life!**

## 💌Credits
Hey, the cars were NOT created by me, but by them:
- 00AbOlFaZl00 
- [ahmeda1999](https://de.gta5-mods.com/users/ahmeda1999)
- Gx_Lover
- [NoHz](https://www.gta5-mods.com/users/NoHz)
- [Rmod Customs](https://de.gta5-mods.com/users/Rmod%20Customs)
- and more...
- I don't know from which people I downloaded the cars.

**If you are also one of the creators, simply create a pull request!**

## ⚠️License
- **If you are a creator and don't want the vehicles to be here on GitHub, just create an issue and pull request!**
- Since we have invested a lot of time in the car, here is the license: [LICENSE](LICENSE)

## ⬇️Downloadlink:
➡️https://drive.google.com/file/d/1ZkERXIxLFY9urkGbhTAbviSvJiuqmhw5/view?usp=sharing

## 📋Download & 🛠️Installation
```
start Fivem-CarRims-Pack
```

### Server.cfg / Cars:
```
start Abarth_124
start AlfaRomeo_155_Q4
start AlfaRomeo_Giulia
start AstonMartin_DB11
start AstonMartin_Vanquish
start AstonMartin_Vantage
start Audi_A6_2020
start Audi_A8_LFSI
start Audi_Q8_2020
start Audi_R8_2020
start Audi_Rs3_2018
start Audi_RS4_2001
start Audi_RS5
start Audi_RS6_2020
start Audi_Rs7_2013
start Audi_s3_2017
start Audi_S8_1998
start Audi_TTRS_2010
start Bentley_Bentayga
start Bentley_Continental_GT_2017
start BMW_750i_e38
start BMW_750Li_G01
start BMW_760LiM_2017
start BMW_E21
start BMW_E82_M1
start BMW_i8
start BMW_m2_F22
start BMW_M3_e30
start BMW_m3_E46
start BMW_M3_E92
start BMW_m3_F80
start BMW_M4_2020
start BMW_M4_F82
start BMW_m5_E60
start BMW_m5_F10
start BMW_m5_F90_Competition
start BMW_m6_F13
start BMW_m8_Competition
start BMW_M135i
start BMW_X6m_F16
start BMW_z4_2019
start Bugatti_Chiron
start Bugatti_Veyron_2009
start Cadillac_CTSV_2016
start Cadillac_GMT900_Escalade
start CamaroSS_1969
start Chevrolet_Camaro_Zl1_2017
start Chevrolet_Colorado_2017
start Chevrolet_Vega_GT_1971
start Corvette_C7
start Corvette_C8
start Corvette_ZR1
start Dodge_Challenger_2016
start Dodge_Charger_1969
start Dodge_Charger_2016
start Dodge_Demon
start Dodge_RAM_2500
start Dodge_Viper_GTS
start Felgen
start Felgen3
start Ferrari_458
start Ferrari_488GTB
start Ferrari_812
start Ferrari_California_2015_Cabrio
start Ferrari_F12_Berlinetta
start Ferrari_F430s
start Ferrari_Laferrari_Aperta
start Ferrari_Pista_Cabrio
start Ford_Fair_500
start Ford_Focus_RS_2017
start Ford_GT_2005
start Ford_GT_2017
start Ford_Mustang_1965
start Ford_Mustang_2019
start Ford_Raptor_2017
start Honda_Civic_TypeR_2017
start Honda_Integra_DC5
start Honda_NSX_2017
start Honda_S2000
start Hyundai_Veloster_N
start Impala_1996_SS
start Jaguar_Fpace
start Jaguar_XK-GT
start Jeep_Grand_Cherokee_Srt8
start Jeep_Wrangler_2012
start Koenigsegg_Agera_2011
start Koenigsegg_CCX
start Koenigsegg_Regera_2016
start Lamborghini_Aventador_2012
start Lamborghini_AventadorSV_2017
start Lamborghini_Centenario
start Lamborghini_Countach
start Lamborghini_Gallardo_Supperlegera_2013
start Lamborghini_Huracan_Lp610
start Lamborghini_Huracan_Performante18
start Lamborghini_Murcierlago_SV
start Lamborghini_Urus
start LandRover_RangeRover_2010
start Lexus_LFA
start Lexus_RCF
start Lkw1
start Lkw3
start Lotus_Elise_l111s
start Lotus_Exige_2012
start Maserati_Grantourismos_2010
start Maserati_MC12
start Mazda_Miata_MX5
start Mazda_RX7_fd
start Mazda_Rx8_2011
start Mclaren_570GT
start Mclaren_600LT
start Mclaren_720s
start Mclaren_GT_2020
start Mclaren_P1
start Mclaren_Senna
start Mercedes_AMG_C63s_2019
start Mercedes_AMG_CLS53_2015
start Mercedes_AMG_E55
start Mercedes_AMG_E63s
start Mercedes_AMG_G63_2019
start Mercedes_AMG_GT63s
start Mercedes_AMG_GTR
start Mercedes_AMG_SLS
start Mercedes_Benz_600SL
start Mercedes_C63_AMG_2012
start Mercedes_E300
start Mercedes_S63w222
start Mercedes_V250
start Mercedes_W202
start Mercedes-Benz_E400
start Mini_Cooper_John_Works_2020
start Mini_cooper_R53
start Mitsubishi_Eclipse
start Mitsubishi_Evo9
start Mitsubishi_EvoX
start Mustang_Boss_429
start Nissan_180sx
start Nissan_350z
start Nissan_Qashqai_2016
start Nissan_R35_Nismo
start Nissan_Silvia_S15
start Nissan_Skyline_R32
start Nissan_Skyline_R34
start Nissan_Skyline_R35
start Pagani_huayra
start Peugeot_205
start Porsche_718Boxster_Cabrio
start Porsche_911_TurboS
start Porsche_911GT3_RS
start Porsche_Carrera_GT
start Porsche_Cayman_718s
start Porsche_GT2_2012
start Porsche_Macan_2019
start Porsche_Panamera_Turbo_2017
start RangeRover_SuperSport
start Renault_Clio_RS_2013
start Renault_Twizy
start RollsRoyce_Wraith
start Scania_4x2
start Subaru_BRZ_2013
start Subaru_WRX_STI_2005
start Suzuki_Grand_vitara
start Tesla_Model_S
start Tesla_ModelX
start Toyota_GT86
start Toyota_JZX100
start Toyota_Mk5_Supra
start Toyota_Prius
start Toyota_Supra_Mk4
start Volvo_850R
start Volvo_S60
start VW_Golf_Mk4
start VW_Golf_Mk7_R
start VW_Touareg_R50
```
